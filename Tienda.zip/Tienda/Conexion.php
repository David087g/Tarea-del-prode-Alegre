<?php
$servername = "localhost";
$username = "root";
$password = "";
$basededatos = "tienda";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $basededatos);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>