<?php
include 'Conexion.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($search) {
    $sql = "SELECT * FROM productos WHERE nombre LIKE '%" . $conn->real_escape_string($search) . "%'";
} else {
    $sql = "SELECT * FROM productos";
}

$result = $conn->query($sql);
?>
