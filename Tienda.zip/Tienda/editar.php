<?php
include 'Conexion.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM productos WHERE id=$id";
    $result = $conn->query($sql);
    $producto = $result->fetch_assoc();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    $sql = "UPDATE productos SET nombre='$nombre', descripcion='$descripcion', precio='$precio' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Se han actualizado los datos del producto'); window.location.href = 'inicio.php';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <header>
    <h1>Editar Producto</h1>
    <h2>editar informacion de producto</h2>
    </header>
    <div class="formularioAgregar">
    <form action="editar.php" method="post">
        <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo $producto['nombre']; ?>" required>
        <label for="descripcion">Descripción:</label>
        <textarea id="descripcion" name="descripcion"><?php echo $producto['descripcion']; ?></textarea>
        <label for="precio">Precio:</label>
        <input type="number" step="0.01" id="precio" name="precio" value="<?php echo $producto['precio']; ?>" required>
        <button type="submit">Actualizar</button>
    </form>
    <a href="inicio.php">Volver a la lista de productos</a>
    </div>+
</body>
</html>
