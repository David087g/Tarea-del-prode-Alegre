<?php
include 'Conexion.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($search) {
    $sql = "SELECT * FROM productos WHERE nombre LIKE '%" . $conn->real_escape_string($search) . "%'";
} else {
    $sql = "SELECT * FROM productos";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1 >Tienda David Mejor que bodega aurera y cosco</h1>
    <h2>Lista de Productos</h2>
    <div class="botonAgregar">
        <a href="agregar.php">Agregar Nuevo Producto</a>
    </div>
    <form method="GET" action="inicio.php">
        <input type="text" name="search" placeholder="Buscar producto por nombre">
        <button type="submit">Buscar</button> <p>Buscar por nombre del producto <a href="Inicio.php">Mira todos los productos aqui</a></p>
    </form>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Editar o Borrar</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['nombre']; ?></td>
                <td><?php echo $row['descripcion']; ?></td>
                <td><?php echo $row['precio']; ?></td>
                <td>
                    <a href="editar.php?id=<?php echo $row['id']; ?>">Editar</a>
                    <a href="eliminar.php?id=<?php echo $row['id']; ?>">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
