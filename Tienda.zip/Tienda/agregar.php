<?php
include 'Conexion.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];

    $sql = "INSERT INTO productos (nombre, descripcion, precio) VALUES ('$nombre', '$descripcion', '$precio')";
    if ($conn->query($sql) === TRUE) {
        header('Location: inicio.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Producto</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <header>
        <h1>Tienda Davis</h1>
        <h2>Agregar Nuevo Producto</h2>
    </header>
    <div class="formularioAgregar">
        <form action="agregar.php" method="post">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion"></textarea>
            
            <label for="precio">Precio:</label>
            <input type="number" step="0.01" id="precio" name="precio" required>
            
            <button type="submit">Agregar</button>
        </form>
        <a href="inicio.php">Volver a la lista de productos</a>
    </div>
</body>
</html>
